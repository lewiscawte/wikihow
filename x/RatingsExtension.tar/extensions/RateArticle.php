<?php
if ( ! defined( 'MEDIAWIKI' ) )
	die();
    
/**#@+
 * An extension that allows users to rate articles. 
 * 
 * @package MediaWiki
 * @subpackage Extensions
 *
 * @link http://www.wikihow.com/WikiHow:RateArticle-Extension Documentation
 *
 *
 * @author Travis Derouin <travis@wikihow.com>
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License 2.0 or later
 */

$wgExtensionFunctions[] = 'wfRateArticle';
$wgShowRatings = true; // set this to false if you want your ratings hidden

require_once("SpecialPage.php");


SpecialPage::AddPage(new UnlistedSpecialPage('RateArticle'));
SpecialPage::AddPage(new UnlistedSpecialPage('ListRatings'));

/**#@+
 */
$wgHooks['AfterArticleDisplayed'][] = array("wfRateArticleForm");

$wgExtensionCredits['parserhook'][] = array(
	'name' => 'RateArticle',
	'author' => 'Travis Derouin',
	'description' => 'Provides a basic article ratings system',
	'url' => 'http://www.wikihow.com/WikiHow:RateArticle-Extension',
);

function wfRateArticle() {
	global $wgMessageCache;
	 $wgMessageCache->addMessages(
        array(
			'listratings' => 'List Rated Pages',
		)
	);
}



function wfRateArticleForm() {
	global $wgOut, $wgArticle, $wgTitle, $wgShowRatings, $wgStylePath;

	$img_path =  $wgStylePath . "/common/images/rating";

	if ($wgArticle == null) return;	
	$page_id = $wgArticle->getID();
	if ($page_id <= 0) return;
	/* use this only for (Main) namespace pages that are not the main page - feel free to remove this... */
	$mainPageObj = Title::newMainPage();
	if ($wgTitle->getNamespace() != NS_MAIN || $mainPageObj->getFullText() == $wgTitle->getFullText()) return;

	$dbr =& wfGetDB( DB_SLAVE);
	$res = $dbr->query("select avg(rat_rating) as R from rating where rat_page=$page_id;");
	$avg = -1;
    while ( $row = $dbr->fetchObject( $res ) ) {
		$avg = $row->R;
	}
    $dbr->freeResult( $res );
	
	$images = array (0, 0, 0, 0, 0);

	// change this if you don't want people seeing the ratings
	if ($wgShowRatings) {
		for ($x = 0; $x < 5; $x++) {
			// $avg = 3.1
			if ($avg >= ($x+1)) $images[$x] = 10;
			else if ($avg -$x < 0)  $images[$x] = 0;
			else $images[$x] = floor(( $avg - $x ) * 10);
		}	
	}
	$target = Title::newFromText("RateArticle", NS_SPECIAL);
	
	echo("
<script type='text/javascript'>
var v = '';

function r(t, r) {
    var requester;
    try {
        requester = new XMLHttpRequest();
    } catch (error) {
        try {
            requester = new ActiveXObject('Microsoft.XMLHTTP');
        } catch (error) {
            return false;
        }
    }
    requester.open('GET', '" . $target->getFullURL() . "?page_id=' + t + '&rating=' + r);
    for (i = 1; i <= 5; i++) {
        var y = document.getElementById(t + '_' + i);
        if (i <= r)
            y.src = '$img_path/check-hover.gif';
        else
            y.src = '$img_path/check-nohover.gif';

    }
    v = v + ';' + t + ';';
    requester.send(null);
    var y = document.getElementById('thanks_' + t);
    y.style.visibility = 'visible';
    y = document.getElementById('rate_' + t);
    y.style.visibility = 'hidden';
}

function m(a, n) {
if (v.indexOf(';' + a + ';') >=0) return;
for (i = 1; i < 6; i++) {
var y = document.getElementById(a + '_' + i);
if (i <= n)
y.src = '$img_path/check-hover.gif';
else
y.src = '$img_path/check-nohover.gif';
}
}


function n(a, p1, p2,p3, p4, p5) {
if (v.indexOf(';' + a + ';') >=0) return;

var y = document.getElementById(a + '_1');
y.src = '$img_path/check-' + p1 + '.gif';
y = document.getElementById(a+'_2');
y.src = '$img_path/check-' + p2 + '.gif';
y = document.getElementById(a+'_3');
y.src = '$img_path/check-' + p3 + '.gif';
y = document.getElementById(a+'_4');
y.src = '$img_path/check-' + p4 + '.gif';
y = document.getElementById(a+'_5');
y.src = '$img_path/check-' + p5 + '.gif';
}

</script>
	");

	$img_str = $images[0] . ", " . $images [1] . ", " . $images[2] . ", " . $images[3] . ", " . $images[4];

		//function n can be changed to accept dynamic parameters representing what rating the article  actually has
echo("
		<div id=page_rating>
		<span id=\"thanks_$page_id\" style=\"visibility:hidden;\">Thanks. Your vote has been counted.</span>
		<span id=\"rate_$page_id\">Rate this article:</span>
		<input type='image' onMouseOver=\"m($page_id,1)\" onMouseOut=\"n($page_id, " .  $img_str  . ")\" src=$img_path/check-" . $images[0] . ".gif id=\"{$page_id}_1\" onclick=\"r($page_id, 1)\">
		<input type='image' onMouseOver=\"m($page_id,2)\" onMouseOut=\"n($page_id, " .  $img_str  . ")\" src=$img_path/check-" . $images[1] . ".gif id=\"{$page_id}_2\" onclick=\"r($page_id, 2)\">
		<input type='image' onMouseOver=\"m($page_id,3)\" onMouseOut=\"n($page_id, " .  $img_str  . ")\" src=$img_path/check-" . $images[2] . ".gif id=\"{$page_id}_3\" onclick=\"r($page_id, 3)\">
		<input type='image' onMouseOver=\"m($page_id,4)\" onMouseOut=\"n($page_id, " .  $img_str  . ")\" src=$img_path/check-" . $images[3] . ".gif id=\"{$page_id}_4\" onclick=\"r($page_id, 4)\">
		<input type='image' onMouseOver=\"m($page_id,5)\" onMouseOut=\"n($page_id, " .  $img_str  . ")\" src=$img_path/check-" . $images[4] . ".gif id=\"{$page_id}_5\" onclick=\"r($page_id, 5)\">
		</div>
	");
}

function wfSpecialRateArticle( $par )
{
    global $wgRequest, $wgSitename, $wgLanguageCode;
    global $wgDeferredUpdateList, $wgOut, $wgUser;

    $fname = "wfRateArticle";

    $rat_page = $wgRequest->getVal("page_id");
    $rat_user = $wgUser->getID();
    $rat_user_text = $wgUser->getName();
    $rat_rating = $wgRequest->getVal('rating');
    $wgOut->disable();

	// disable ratings more than 5, less than 1
	if ($rat_rating > 5 || $rat_rating < 1) return;

    $dbw =& wfGetDB( DB_MASTER );
    $dbw->insert( 'rating',
         array( 'rat_page' => $rat_page,
                'rat_user' => $rat_user,
                'rat_user_text' => $rat_user_text,
                'rat_rating' => $rat_rating),
         $fname);

}

function wfSpecialListRatings ($par) {
	global $wgOut, $wgUser, $wgShowRatings;

	// Just change this if you don't want users seeing the ratings
	if (!$wgShowRatings) {
		$wgOut->addHTML("Sorry! This page is not enabled.");
		return;
	}

	$wgOut->addHTML("<ol>");
	$sk = $wgUser->getSkin();
	//TODO add something for viewing ratings 51-100, 101-150, etc	
	$dbr =& wfGetDB( DB_SLAVE);
	$res = $dbr->query("select rat_page, avg(rat_rating) as R, count(*) as C from rating group by rat_page order by R DESC limit 50;");
     while ( $row = $dbr->fetchObject( $res ) ) {
   			 $t = Title::newFromID($row->rat_page);
		 	 if ($t == null) continue; $wgOut->addHTML("<li>" . $sk->makeLinkObj($t, $t->getFullText() ) . " ({$row->C}, {$row->R})</li>"); 
		 	 //$wgOut->addHTML("<li>" . $row->rat_page . "</li>"); 
	 }
    $dbr->freeResult( $res );
	$wgOut->addHTML("</ol>");
	
}

?>
