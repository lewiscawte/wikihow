<?php
if ( ! defined( 'MEDIAWIKI' ) )
	die();
    
/**#@+
 * An extension that allows users to rate articles. 
 * 
 * @package MediaWiki
 * @subpackage Extensions
 *
 * @link http://www.wikihow.com/WikiHow:SpamDiffTool-Extension Documentation
 *
 *
 * @author Travis Derouin <travis@wikihow.com>
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License 2.0 or later
 */

$wgExtensionFunctions[] = 'wfSpamDiffTool';
$wgSpamBlacklistArticle = "Spam-Blacklist";

require_once("SpecialPage.php");
require_once("SpecialBlockip.php");


SpecialPage::AddPage(new UnlistedSpecialPage('SpamDiffTool'));


$wgExtensionCredits['other'][] = array(
	'name' => 'SpamDiffTool',
	'author' => 'Travis Derouin',
	'description' => 'Provides a basic way of adding new entries to the Spam Blacklist from diff pages',
	'url' => 'http://www.wikihow.com/WikiHow:SpamDiffTool-Extension',
);

function wfSpamDiffTool() {
	global $wgMessageCache;
	 $wgMessageCache->addMessages(
 	array(
			'spamdifftool' => 'Manage Spam Blacklist',
			'spamdifftool_cantedit' => 'Sorry - you don\'t have permission to edit the Spam Blacklist.',
			'spamdifftool_notext' => 'There is no text to add to the Spam Blacklist. Click <a href=\'$1\'>here</a> to continue. ',
			'spamdifftool_confirm' => 'Confirm that you want to add these entries to the Spam Blacklist. (Click <a href=\'http://www.wikihow.com/forum/posting.php?mode=newtopic&f=6\' target=\'new\'>here</a> to report a problem.)',
			'spamdifftool_summary' => 'Adding to Spam Blacklist',
			'spamdifftool_urls_detected' => 'The following URLs were detected in the edit(s), which ones would you like to add to the Spam Blacklist? These options order from more restrictive to less restrictive, blocking the entire domain will block all links to anything coming from that domain. <br/><br/>Be sure not to block entire domains that host user accounts, like blogpost.com, geocities.com, etc. ',
			'spamdifftool_no_urls_detected' => 'No urls were detected. Click <a href=\'$1\'>here</a> to return.',
			'spamdifftool_spam_link_text' => 'add to spam',
			'spamdifftool_option_domain' => 'all from this domain',
			'spamdifftool_option_subdomain' => 'all from this subdomain',
			'spamdifftool_option_directory' => 'this subdomain and directory',
			'spamdifftool_option_none' => 'nothing',
			'spamdifftool_block'		=> 'Block:',
		)
	);
}



function wfSpamDiffLink($title) {
	global $wgUser, $wgRequest, $wgSpamBlacklistArticle;
	$sk = $wgUser->getSkin();
	$sb = Title::newFromDBKey($wgSpamBlacklistArticle);
	if (!$sb->userCanEdit()) {
		return '';
	}
	$link = '[' . $sk->makeKnownLinkObj( Title::newFromText("SpamDiffTool", NS_SPECIAL), wfMsg('spamdifftool_spam_link_text'),
                'target=' . $title->getPrefixedURL().
                '&oldid=' . $wgRequest->getVal('oldid') .
                '&rcid='. $wgRequest->getVal('rcid') .
                '&diff2='. $wgRequest->getVal('diff')  .
                '&returnto=' . urlencode($_SERVER['QUERY_STRING'])
                ) .
                ']';

	return $link;
}

function wfSpecialSpamDiffTool() {
	global $wgRequest, $wgContLang, $wgOut, $wgSpamBlacklistArticle, $wgUser, $wgScript;
		$title = Title::newFromDBKey($wgRequest->getVal('target'));
        $diff = $wgRequest->getVal( 'diff2' );
        $rcid = $wgRequest->getVal( 'rcid' );
        $rdfrom = $wgRequest->getVal( 'rdfrom' );


		// can the user even edit this?
		$sb = Title::newFromDBKey($wgSpamBlacklistArticle);
		if (!$sb->userCanEdit()) {
			$wgOut->addHTML(wfMsg('spamdifftool_cantedit'));
			return;
		}
		// do the processing
		if ($wgRequest->wasPosted() ) {

			if ($wgRequest->getVal('confirm', null) != null) {
				$t = Title::newFromDBKey($wgSpamBlacklistArticle);
				$a = new Article(&$t);
				$text = $a->getContent();

				// insert the before the <pre> at the bottom  if there is one
				$i = strrpos($text, "</pre>");
				if ($i !== false) {
					$text = substr($text, 0, $i)
							. $wgRequest->getVal('newurls')
							. "\n" . substr($text, $i);	
				} else {  
					$text .= "\n" . $wgRequest->getVal('newurls');
				} 
			    $watch = false;
    			if ($wgUser->getID() > 0) 
       			$watch = $wgUser->isWatched($t);
				$a->updateArticle($text, wfMsg('spamdifftool_summary'), false, $watch);
				$returnto = $wgRequest->getVal('returnto', null);
				if ($returnto != null && $returnto != '') 	
					$wgOut->redirect($wgScript . "?" . urldecode($returnto) ); // clear the redirect set by updateArticle
				return;
			}
			$vals = $wgRequest->getValues();
			$text = ''; 
			$urls = array();
			foreach ($vals as $key=>$value) {
				if (strpos($key, "http://") === 0) {
					$url = str_replace("%2E", ".", $key);
					if ($value == 'none') continue;
					switch ($value) {
						case 'domain':
//							$url = str_replace("http://", "", $url);
							//$url = preg_replace("/(.*[^\/])*\/.*/", "$1", $url); // trim everything after the slash
							$url = preg_replace("@^http://([^/]*\.)?([^./]+\.[^./]+).*$@", "$2", $url);
							//$k = split('\.', $url);
							//$url = $k[sizeof($k) - 2] . "." . $k[sizeof($k) - 1];
							$url = str_replace(".", "\.", $url); // escape the periods
							break;
						case 'subdomain':
							$url = str_replace("http://", "", $url);
							$url = str_replace(".", "\.", $url); // escape the periods
							$url = preg_replace("/^([^\/]*)\/.*/", "$1", $url); // trim everything after the slash
							break;
						case 'dir':
							$url = str_replace("http://", "", $url);
							$url = preg_replace("@^([^/]*\.)?([^./]+\.[^./]+(/[^/?]*)?).*$@", "$1$2", $url); // trim everything after the slash
							$url = preg_replace("/^(.*)\/$/", "$1", $url); // trim trailing / if one exists
							$url = str_replace(".", "\.", $url); // escape the periods
							$url = str_replace("/", "\/", $url); // escape the slashes
							break;	
					}
					if (!isset($urls[$url]) ){
						$text .= "$url\n";
						$urls[$url] = true;
					}
				}
			}
			if (trim($text) == '') {
				$wgOut->addHTML( wfMsg('spamdifftool_notext', $wgScript . "?" . urldecode($wgRequest->getVal('returnto') )));
				return;		
			}
			$wgOut->addHTML("<form method=POST>
					<input type='hidden' name='confirm' value='true'>
					<input type='hidden' name='newurls' value=\"" . htmlspecialchars($text) . "\">
					<input type='hidden' name='returnto' value=\"" . htmlspecialchars($wgRequest->getVal('returnto')) . "\">
				");
			$wgOut->addHTML(wfMsg('spamdifftool_confirm') . "<pre>$text</pre>");
			$wgOut->addHTML("</table><input type=submit value=\"" . htmlspecialchars(wfMsg('submit')) . "\"></form>");
			return;
		}
        if ( !is_null( $diff ) ) {
            require_once( 'DifferenceEngine.php' );
			
	        # Get the last edit not by this guy
			$current = Revision::newFromTitle( $title );
 			$dbw =& wfGetDB( DB_MASTER );
	        $user = intval( $current->getUser() );
	        $user_text = $dbw->addQuotes( $current->getUserText() );
	        $s = $dbw->selectRow( 'revision',
	            array( 'rev_id', 'rev_timestamp' ),
	            array(
	                'rev_page' => $current->getPage(),
	                "rev_user <> {$user} OR rev_user_text <> {$user_text}"
	            ), $fname,
	            array(
	                'USE INDEX' => 'page_timestamp',
                'ORDER BY'  => 'rev_timestamp DESC' )
           );
			if ($s) {
				// set oldid
				$oldid = $s->rev_id;
			}
            $de = new DifferenceEngine( $title, $oldid, $diff, $rcid );
			$de->loadText();
			$otext = $de->mOldtext;
			$ntext = $de->mNewtext;
        	$ota = explode( "\n", $wgContLang->segmentForDiff( $otext ) );
        	$nta = explode( "\n", $wgContLang->segmentForDiff( $ntext ) );
        	$diffs =& new Diff( $ota, $nta );
       	    foreach ($diffs->edits as $edit) {
            	if ($edit->type != 'copy') {
					$text .= implode("\n", $edit->closing) . "\n";
				}
			}
		} else {
			$a = new Article($title);
			$text = $a->getContent(true);
		}	

//header("Content-type: text/plain;");
$matches = array();
$preg = "/http:\/\/[^] \n'\">]*/";
preg_match_all($preg, $text, $matches);
//exit;
			if (sizeof($matches[0]) == 0) {
				$wgOut->addHTML( wfMsg('spamdifftool_no_urls_detected', $wgScript . "?" . urldecode($wgRequest->getVal('returnto') )));
				return;
			}
			
/*			if( $wgUser->isAllowed( 'block' ) ) {
			    $ipb = new IPBlockForm( $par );
				$ipb->showForm( '' );
			}
			*/

			$wgOut->addHTML("
		<form method='POST'>
					<input type='hidden' name='returnto' value=\"" . htmlspecialchars($wgRequest->getVal('returnto')) . "\">
				<style type='text/css'>
						td.spam-url-row {
							border: 1px solid #ccc; 
						}
				</style> " . wfMsg('spamdifftool_urls_detected') . "
			<br/><br/><table cellpadding='5px' width='100%'>");
		
			$urls = array();	
			foreach ($matches as $match) {
				foreach ($match as $url) {
					if (isset($urls[$url])) continue; // avoid dupes
					$urls[$url] = true;
					$name = htmlspecialchars(str_replace(".", "%2E", $url));
					$wgOut->addHTML("<tr>
						<td class='spam-url-row'><b>$url</b><br/>
						" . wfMsg('spamdifftool_block') . " &nbsp;&nbsp;
						<INPUT type='radio' name=\"" . $name . "\"	value='domain' checked> " . wfMsg('spamdifftool_option_domain') . "
						<INPUT type='radio' name=\"" . $name . "\"	value='subdomain'> " . wfMsg('spamdifftool_option_subdomain') . " 
						<INPUT type='radio' name=\"" . $name . "\"	value='dir'>" . wfMsg('spamdifftool_option_directory') . " 
						<INPUT type='radio' name=\"" . $name . "\"	value='none'>" . wfMsg('spamdifftool_option_none') . " 
					</td>
					</tr>	
					");
				}
			}
			$wgOut->addHTML("</table><input type=submit value=\"" . htmlspecialchars(wfMsg('submit')) . "\"></form>");
            // DifferenceEngine directly fetched the revision:
            $RevIdFetched = $de->mNewid;
            //$de->showDiffPage();
}

