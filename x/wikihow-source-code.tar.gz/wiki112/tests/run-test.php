<?php

require_once( dirname(__FILE__) . '/../maintenance/commandLine.inc' );
ini_set( 'include_path', get_include_path() . PATH_SEPARATOR . /*$_SERVER['PHP_PEAR_INSTALL_DIR']*/ 'C:\php\pear' );
require( 'PHPUnit/TextUI/Command.php' );


