<?php
/** Turkmen (Türkmen)
 *
 * @addtogroup Language
 *
 */

$messages = array(
'redirectedfrom' => '($1 sahypasyndan gönükdirildi)',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'mainpage' => 'Baş Sahypa',

# Move page
'1movedto2' => '[[$1]] sahypasy [[$2]] sahypasyna göçürildi',

);
