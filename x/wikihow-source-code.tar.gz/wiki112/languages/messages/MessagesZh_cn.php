<?php
/**
  * Chinese (PRC) (中文 (中国大陆))
  *
  * @addtogroup Language
  */

# Inherit everything for now
$fallback = 'zh-hans';

