<?php
/** Serbian Latin iyekavian (ijekavica)
 *
 * @addtogroup Language
 *
 */

# Inherit everything for now
$fallback = 'sr-ec';

