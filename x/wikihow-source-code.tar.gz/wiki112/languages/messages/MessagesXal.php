<?php
/** Kalmyk (Хальмг)
 *
 * @addtogroup Language
 *
 * @author M.M.S.
 * @author לערי ריינהארט
 */

$namespaceNames = array(
	NS_MEDIA            => 'Аһар',
	NS_SPECIAL          => 'Көдлхнə',
	NS_MAIN             => '',
	NS_TALK             => 'Ухалвр',
	NS_USER             => 'Орлцач',
	NS_USER_TALK        => 'Орлцачна_тускар_ухалвр',
	# NS_PROJECT set by $wgMetaNamespace
	NS_PROJECT_TALK     => '$1_тускар_ухалвр',
	NS_IMAGE            => 'Зург',
	NS_IMAGE_TALK       => 'Зургин_тускар_ухалвр',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_тускар_ухалвр',
	NS_TEMPLATE         => 'Зура',
	NS_TEMPLATE_TALK    => 'Зуран_тускар_ухалвр',
	NS_HELP             => 'Цəəлһлһн',
	NS_HELP_TALK        => 'Цəəлһлһин_тускар_ухалвр',
	NS_CATEGORY         => 'Янз',
	NS_CATEGORY_TALK    => 'Янзин_тускар_ухалвр',
);

$fallback8bitEncoding = "windows-1251";

$messages = array(
'article' => 'Халх',
'mytalk'  => 'Мини күүндлһн бəəрм',

'history'          => 'Чикллһнə бүрткл',
'history_short'    => 'Чикллһнə бүрткл',
'edit'             => 'Чиклх',
'talkpage'         => 'Ухалвр',
'talkpagelinktext' => 'Ухалвр',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'mainpage' => 'Эклц',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-main'     => 'Халх',
'nstab-user'     => 'Орлцач',
'nstab-template' => 'Зура',
'nstab-help'     => 'Цəəлһлһн',
'nstab-category' => 'Янз',

# Login and logout pages
'login'         => 'Оруллһн',
'createaccount' => 'Выль вики-авторлэн регистрациез',

# Preferences page
'preferences' => 'Дурллһн',

# Image list
'filehist-user' => 'Орлцач',

# Contributions
'mycontris' => 'Мини өгүллһдүд',

);
