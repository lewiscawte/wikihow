<?php
/** Eastern Yiddish (מיזרח־ייִדיש)
 *
 * @addtogroup Language
 *
 */

$rtl = true;
$fallback = 'yi';

