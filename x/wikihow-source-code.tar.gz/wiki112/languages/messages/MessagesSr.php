<?php
/** Serbian (Српски / Srpski)
 *
 * @addtogroup Language
 *
 */

$fallback = 'sr-ec';
$linkTrail = '/^([abvgdđežzijklljmnnjoprstćufhcčdžšабвгдђежзијклљмнњопрстћуфхцчџш]+)(.*)$/usD';

