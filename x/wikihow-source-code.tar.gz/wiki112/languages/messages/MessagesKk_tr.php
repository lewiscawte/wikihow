<?php
/** ‪Kazakh (Turkey)‬ (‪Qazaqşa (Türkïya)‬)
 *
 * @addtogroup Language
 *
 */

# Inherit everything for now
$fallback = 'kk-latn';

