<?php
/** Crimean Turkish (Qırımtatarca)
 *
 * @addtogroup Language
 *
 * @author Alessandro
 */

$fallback = 'crh-latn';

$linkTrail = '/^([a-zâçğıñöşüа-яёʺʹ“»]+)(.*)$/sDu';

