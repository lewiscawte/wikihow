<?php
/** Yue (粵語)
 *
 * @addtogroup Language
 *
 */

# Inherit everything for now
$fallback = 'yue';

