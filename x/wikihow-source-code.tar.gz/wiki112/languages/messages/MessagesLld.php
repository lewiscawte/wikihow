<?php
/** Ladin (Ladin)
 *
 * @addtogroup Language
 *
 */

$fallback = 'it';

