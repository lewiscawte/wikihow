<?php
/** Alemannisch
  *
  * @addtogroup Language
  * @comment Deprecated code. Falls back to 'gsw'.
  */

$fallback = 'gsw';
