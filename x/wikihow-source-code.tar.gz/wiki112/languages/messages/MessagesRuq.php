<?php
/** Megleno-Romanian (Vlăheşte)
 *
 * @addtogroup Language
 * @comment redirects to Megleno-Romanian (Latin)
 *
 */

$fallback = 'ruq-latn';

