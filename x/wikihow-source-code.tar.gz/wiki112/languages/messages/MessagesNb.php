<?php
/** Norwegian Bokmål (‪Norsk (bokmål)‬)
 *
 * @addtogroup Language
 * @comment Correct code, but for historical reasons this started as 'no'. Falls back to 'no'. May be reversed some day.
 */

$fallback = 'no';

