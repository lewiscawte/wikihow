<?php
/** Kazakh (China) (قازاقشا (جۇنگو))
 *
 * @addtogroup Language
 *
 */

# Inherit everything for now
$fallback = 'kk-arab';

