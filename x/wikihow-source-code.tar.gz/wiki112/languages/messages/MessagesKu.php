<?php
/** Kurdish (Kurdî / كوردی)
 *
 * @addtogroup Language
 *
 */

$fallback = 'ku-latn';

