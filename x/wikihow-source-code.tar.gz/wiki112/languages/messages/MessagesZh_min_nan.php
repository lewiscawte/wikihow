<?php
/** Min Nan Chinese (Bân-lâm-gú)
 *
 * @addtogroup Language
 *
 */

# Inherit everything for now
$fallback = 'nan';

