<?php
/** Danish (Dansk)
  *
  * @addtogroup Language
  * @comment Deprecated code. Falls back to 'dk'.
  */

$fallback = 'da';
