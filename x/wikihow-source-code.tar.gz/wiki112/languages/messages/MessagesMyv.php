<?php
/** Erzya (эрзянь кель)
 *
 * @addtogroup Language
 *
 * @author Erzianj jurnalist
 * @author Botuzhaleny-sodamo
 * @author MF-Warburg
 * @author Tupikovs
 * @author Sura
 * @author Nike
 * @author Max sonnelid
 * @author Amdf
 * @author SPQRobin
 * @author Siebrand
 */



$messages = array(
# User preference toggles
'tog-underline'               => 'Сюлмавомапетнень алга черькстамс:',
'tog-highlightbroken'         => 'Петемс синдтрень сюлмавомапетнень <a href="" class="new">вана  истя</a>(лиякс вана истя<a href="" class="internal">?</a>).',
'tog-justify'                 => 'Вейкетстявтомс сёрмадовксушодоманть лопанть кувалмга',
'tog-hideminor'               => 'Од полавтоматнесэ кекшемс вишинькине витевкстнэнь',
'tog-extendwatchlist'         => 'Келейгавтомс ваномань сёрмалевксэнть весе полавтнематнень невтемга',
'tog-usenewrc'                => 'Вадрялгавтозь од лиякстомат  (JavaScript)',
'tog-numberheadings'          => 'Сёрмадовксконяксос кадык сынсь ловомавалтнэ путовить',
'tog-showtoolbar'             => 'Кедьёнкс лазнэнть невтемс сёрмадома шкасто (JavaScript)',
'tog-editondblclick'          => 'Кавксть лепштязь совамс сёрмадовксонь витнеме-петнеме (JavaScript)',
'tog-editsection'             => 'Невтемс сюлмавомапенть «витемс» эрьва секциянтень-пельксэнтень',
'tog-editsectiononrightclick' => 'Витнемс секциятнень-пелькстнэнь, лепштямс сёрмадовксонть лемензэ лангс чэерень витьёнсе повнэсэ  (JavaScript)',
'tog-showtoc'                 => 'Невтемс сёрмадовкс потмокс (лопатненень, конатнесэ 3-до ламо сёрмадовкст)',
'tog-rememberpassword'        => 'Ванстомс салавань валом те арсиймашинасонть',
'tog-editwidth'               => 'Витема паксясь весе браузер вальманть келесэ',
'tog-watchcreations'          => 'Совавтомс монь тевть лопатнень ванома лемрисьмезэнь',
'tog-watchdefault'            => 'Совавтомс монь витевть лопатнень ванома лемрисьмезэнь',
'tog-watchmoves'              => 'Лопанть лиякстомтса, совавтык ванома лемрисьмезэнь',
'tog-watchdeletion'           => 'Лопанть нардаса, совавтык сонзэ ванома лемрисьмезэнь',
'tog-minordefault'            => 'Тешкстамс витевкстнэнь апокшкэкс, бути лиякс апак ёвта',
'tog-previewontop'            => 'Невтемс сёрмадовксонть васнянь невтевксэнь вальманть витеманьседенть икеле',
'tog-previewonfirst'          => 'Васнянь невтевкс васенцеде витнемстэ-петнемстэ',
'tog-nocache'                 => 'А мерема лопатнень кешировамс',
'tog-enotifwatchlistpages'    => 'Пачтямс е-сёрмасо ванома лемрисьмесэнь теезь лиякстомтоматнеде',
'tog-enotifusertalkpages'     => 'Пачтямс е-сёрма совицянь ванома лемрисьмесэнь теезь  лиякстомтоматнеде',
'tog-enotifminoredits'        => 'Пачтямс е-сёрмасо лиякстомтоматнеде, сестэяк зярдо апокшкынеть',
'tog-enotifrevealaddr'        => 'Штавтомс е-сёрмань адресэм яволявтомань сёрмадовкстнэсэ',
'tog-shownumberswatching'     => 'Невтемс зяро совицятнеде, конат аравтызь лопанть эсест ванома лемрисьментень',
'tog-fancysig'                => 'Верек лемпутовкст (сонсь теевиця сюлмавома певтеме)',
'tog-externaleditor'          => 'Апак кевксте нолдык тевс ушоёнонь витнемканть',
'tog-externaldiff'            => 'Апак кевксте нолдык тевс ушоёнонь diff',
'tog-showjumplinks'           => 'Меремс "тёкадемс" маласпонгомань сюлмавомапетнес',
'tog-uselivepreview'          => 'Максомс эряй васнянь невтевкс (JavaScript) (Варчамонь)',
'tog-forceeditsummary'        => 'Невтик монень, мезе сёрмадомс витнемадо-петнемадо ёвтамонь вальминентень',
'tog-watchlisthideown'        => 'Кекшить монь теевть витневкстнэнь ванома лемрисьменть эйстэ',
'tog-watchlisthidebots'       => 'Кекшить бот витневкстнэнь-петневкстнэнь ванома лемрисьсенть эйстэ',
'tog-watchlisthideminor'      => 'Кекшить апокшкыне витневкстнэнь ванома лемрисьменть эйстэ',
'tog-nolangconversion'        => 'А меремс вариантонь полавтома лия лангс',
'tog-ccmeonemails'            => 'Кучт монень копия е-сёрматнеде, конатнень кучан лия совицянень',
'tog-diffonly'                => 'Иляк невтне лопапотмоксонть diffs ало',

'underline-always'  => 'Свал',
'underline-never'   => 'Зярдояк',
'underline-default' => 'Васнянь браузер',

'skinpreview' => '(Васнянь невтевкс)',

# Dates
'sunday'        => 'Таргочи',
'monday'        => 'Атяньчи',
'tuesday'       => 'Вастаньчи',
'wednesday'     => 'Куншкачи',
'thursday'      => 'Калоньчи',
'friday'        => 'Сюконьчи',
'saturday'      => 'Шлямочи',
'sun'           => 'Тар',
'mon'           => 'Атя',
'tue'           => 'Вас',
'wed'           => 'Кун',
'thu'           => 'Кал',
'fri'           => 'Сюк',
'sat'           => 'Шля',
'january'       => 'Якшамков',
'february'      => 'Даволков',
'march'         => 'Эйзюрков',
'april'         => 'Чадыков',
'may_long'      => 'Панжиков',
'june'          => 'Аштемков',
'july'          => 'Медьков',
'august'        => 'Умарьков',
'september'     => 'Таштамков',
'october'       => 'Ожоков',
'november'      => 'Сундерьков',
'december'      => 'Ацамков',
'january-gen'   => 'Якшамковонь',
'february-gen'  => 'Даволковонь',
'march-gen'     => 'Эйзюрковонь',
'april-gen'     => 'Чадыковонь',
'may-gen'       => 'Панжыковонь',
'june-gen'      => 'Аштемковонь',
'july-gen'      => 'Медьковонь',
'august-gen'    => 'Умарьковонь',
'september-gen' => 'Таштамковонь',
'october-gen'   => 'Ожоковонь',
'november-gen'  => 'Сунденьковонь',
'december-gen'  => 'Ацамковонь',
'jan'           => 'Якш',
'feb'           => 'Дав',
'mar'           => 'Эйз',
'apr'           => 'Чад',
'may'           => 'Пан',
'jun'           => 'Ашт',
'jul'           => 'Мед',
'aug'           => 'Ума',
'sep'           => 'Таш',
'oct'           => 'Ожо',
'nov'           => 'Сун',
'dec'           => 'Аца',

# Bits of text used by many pages
'categories'            => 'Категорият',
'pagecategories'        => '{{PLURAL:$1|Категория|Категорият}}',
'category_header'       => '"$1" категориясонть лопатне',
'subcategories'         => 'Алкскатегорият',
'category-media-header' => '"$1" категориясонть медиясь',
'category-empty'        => "''Те категориясонть арасть лопат-медият.''",

'mainpagetext' => "<покш>'''МедияВикинь тевс аравтомазо парсте лиссь.'''</покш>",

'about'          => 'Эстедензэ',
'article'        => 'Потмокслопа',
'newwindow'      => '(панжови од вальмасо)',
'cancel'         => 'Саемс мекев',
'qbfind'         => 'Мук',
'qbbrowse'       => 'Ваномо-тееме',
'qbedit'         => 'Витнеме-петнеме',
'qbpageoptions'  => 'Те лопась',
'qbpageinfo'     => 'Косо-зярдо',
'qbmyoptions'    => 'Монь лопан',
'qbspecialpages' => 'Башка тевень лопат',
'moredotdotdot'  => 'Седе ламо...',
'mypage'         => 'Монь лопам',
'mytalk'         => 'Монь кортамом',
'anontalk'       => 'Кортамс те IP-нть марто',
'navigation'     => 'Навигациянть',
'and'            => 'ды',

# Metadata in edit box
'metadata_help' => 'Метадата:',

'errorpagetitle'    => 'Ильведькс',
'returnto'          => 'Велявтомс $1.',
'tagline'           => '{{SITENAME}} туртов',
'help'              => 'Лезкс',
'search'            => 'Вешнемс',
'searchbutton'      => 'Вешнек',
'go'                => 'Адя',
'searcharticle'     => 'Адя',
'history'           => 'Лопань полавтнемат - витнемат',
'history_short'     => 'История',
'updatedmarker'     => 'меельседе сакшномадот мейле полавтовсь',
'info_short'        => 'Мезе содамс',
'printableversion'  => 'Ливтевиця версия',
'permalink'         => 'Свалшкас сюлмавомапе',
'print'             => 'Нолдамс',
'edit'              => 'Витнеме-петнеме',
'editthispage'      => 'Витнемс-петнемс те лопанть',
'delete'            => 'Нардамс',
'deletethispage'    => 'Нардамс те лопанть',
'undelete_short'    => 'Велявтомс нардазенть {{PLURAL:$1|вейке витнема-петнема|$1 витнемат-петнемат}}',
'protect'           => 'Аравтомс прянь ванстомас',
'protect_change'    => 'полавтомс прянь ванстома лувонть',
'protectthispage'   => 'Аравтомс те лопанть ванстомас',
'unprotect'         => 'Саемс прянь ванстомасто',
'unprotectthispage' => 'Саемс те лопанть ванстомасто',
'newpage'           => 'Од лопа',
'talkpage'          => 'Кортнемс те лопадонть',
'talkpagelinktext'  => 'Кортнеме',
'specialpage'       => 'Башка тевень лопа',
'personaltools'     => 'Эсень кедьёнкст',
'postcomment'       => 'Кучомс арсема марто сёрма',
'articlepage'       => 'Ваномс потмокслопанть',
'talk'              => 'Кортнеме',
'views'             => 'Ваномкат',
'toolbox'           => 'Кедьёнкс парго',
'userpage'          => 'Ваномонзо кирдицянть лопанзо',
'projectpage'       => 'Ваномонзо проектенть лопанть',
'imagepage'         => 'Ваномс артовкстнэнь-фотокувотнень лопанть',
'mediawikipage'     => 'Невтемензе сёрма паргонть лопанть',
'templatepage'      => 'Ванномс лопапарцунонь лопанть',
'viewhelppage'      => 'Ванномс лезкслопанть',
'categorypage'      => 'Ванномс категориянь лопанть',
'viewtalkpage'      => 'Ванномс мезде молить кортнемат',
'otherlanguages'    => 'Лия кельсэ',
'redirectedfrom'    => '(Ютавтозь $1 вельде)',
'redirectpagesub'   => 'Лиясто ютавтозь лопа',
'lastmodifiedat'    => 'Те лопанть меельседе витнезь-петнезь $2, $1.', # $1 date, $2 time
'protectedpage'     => 'Те лопась ванстомасо',
'jumpto'            => 'Тёкадемс тей:',
'jumptonavigation'  => 'Новигациясь-лездамось',
'jumptosearch'      => 'вешнеме',

# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'aboutsite'         => '{{SITENAME}} ланга',
'aboutpage'         => 'Проектесь:Эстедендэ',
'bugreports'        => 'Вишка сёрмадовкс ильветькстэ',
'bugreportspage'    => 'Проектэсь:Вишка сёрмадовкс ильветькстэ',
'copyrightpagename' => '{{SITENAME}} копиянь теемань прават',
'copyrightpage'     => '{{ns:project}}:Ломанень видечинзэ',
'currentevents'     => 'Мезе ней моли',
'currentevents-url' => 'Project:Мезе ней моли',
'disclaimers'       => 'Видечинь кортамотьне',
'disclaimerpage'    => 'Project:Видечинь кемекстамонть лоткавтома',
'edithelp'          => 'Витнемань-петнемань лезкс',
'edithelppage'      => 'Лескс:Витнема-петнема',
'faq'               => 'Сеедьстэ кепедень кевкстемат',
'faqpage'           => 'Project:Сеедьстэ кепедень кевкстемат',
'helppage'          => 'Лезкс',
'mainpage'          => 'Прякслопа',
'policy-url'        => 'Project:Политика',
'portal'            => 'Велень-сядонь вальма',
'portal-url'        => 'Проект:Вейтьсэнь вальма',
'privacy'           => 'Салавачинь полициясь',
'privacypage'       => 'Проектесь:Салавачинь политикась',
'sitesupport'       => 'Лезксйармаконь максома',
'sitesupport-url'   => 'Project:Вальманть лездамось',

'badaccess'        => 'Меревемань асатыкс',
'badaccess-group0' => 'Тонеть а мерить теемс мезе вешить.',

'versionrequired' => 'МедияВикинь $1 версиясь эряви',

'ok'                      => 'Маштови',
'retrievedfrom'           => 'Лисмапрясь "$1"-сто',
'youhavenewmessages'      => 'Тынь саиде $1 ($2).',
'newmessageslink'         => 'Од нурька сёрмадт',
'newmessagesdifflink'     => 'меельсе полавтома',
'youhavenewmessagesmulti' => 'Од сёрминеть учить эйсэть $1-со',
'editsection'             => 'витнемс-петнемс',
'editold'                 => 'витнемс-петнемс',
'editsectionhint'         => 'Витемс секциянть-пельксэнть: $1',
'toc'                     => 'Потмокс',
'showtoc'                 => 'невтемс',
'hidetoc'                 => 'кекшемс',
'thisisdeleted'           => '$1-нть ваномс эли велявтомс мекев?',
'viewdeleted'             => 'Ванномс $1?',
'feedlinks'               => 'Максовкс:',
'site-rss-feed'           => 'RSS-нть максовкс $1 -нть кисе',
'site-atom-feed'          => 'Atom-нть максовкс $1-нть кисе',
'page-rss-feed'           => '«$1» RSS максовкс',
'page-atom-feed'          => '«$1» Atom максовкс',

# Short words for each namespace, by default used in the namespace tab in monobook
'nstab-main'      => 'Лопа',
'nstab-user'      => 'Совицянь лопась',
'nstab-media'     => 'Кулянь пачтямо керькстнэнь лопась',
'nstab-special'   => 'Башка тев',
'nstab-project'   => 'Проектэнь лопа',
'nstab-image'     => 'Файла',
'nstab-mediawiki' => 'Сёрмине',
'nstab-template'  => 'Лопапарцун',
'nstab-help'      => 'Лезкс лопа',
'nstab-category'  => 'Категория',

# Main script and global functions
'nosuchaction'      => 'Истямо тев арась',
'nosuchspecialpage' => 'Истямо башка лопа арась',

# General errors
'error'              => 'Ильведькс',
'databaseerror'      => 'Датабазань ильведькс',
'readonly'           => 'Датабазась панжома экшсэ',
'internalerror'      => 'Потмонь ильведькс',
'internalerror_info' => 'Потмонь ильведькс: $1',
'filecopyerror'      => '"$1" файлась эзь ванстово од "$2" файлакс.',
'filerenameerror'    => 'Файлантень а маштови "$1" максомс од лем "$2".',
'filedeleteerror'    => '"$1" файлась шукшпряв эзь ливтеве.',
'filenotfound'       => '"$1" файлась а муеви.',
'fileexistserror'    => 'Файлась "$1" а сёрмадови: ули уш истямо',
'formerror'          => 'Ильведевкс: Формась а кучови',
'badtitle'           => 'Амаштовикс конякс',
'badtitletext'       => 'Вешезезь лопанть лемезе аульвиде, чаво, али ауль видесте невтезть келеньутковань али интервикинь лемесь. Паряк, лемесэнть тевсь нолдазь аульнолдавикс тешкст.',
'viewsource'         => 'Ванномс лисьмапрянть',
'viewsourcefor'      => ' $1 -нь юртозо',
'protectedpagetext'  => 'Те лопась панжома экшсэ, илязо понго витнемс - петнемс киненьгак.',
'viewsourcetext'     => 'Тынь сонзе вансынк ды тейдят копиянть лисмапрясто те лопастонть:',

# Login and logout pages
'logouttitle'               => 'Совицянь лисема',
'loginpagetitle'            => 'Совицянь совамо',
'yourname'                  => 'Совицянь лем:',
'yourpassword'              => 'Кирдицянь сёрмадовкс:',
'yourpasswordagain'         => 'Омбоцеде сёрмадык кирдицянь леметь:',
'remembermypassword'        => 'Лецтемга монь салава валом те арсемашинасонть',
'yourdomainname'            => 'Эсеть доменэть:',
'login'                     => 'Совамо',
'loginprompt'               => 'Тынь меремс cookies-не совамоньть кувалт {{SITENAME}}-те.',
'userlogin'                 => 'Совамо / тейть совамотарка',
'logout'                    => 'Лисеме',
'userlogout'                => 'Лисевить',
'notloggedin'               => 'Апак соваво',
'nologin'                   => 'Совамотаркат арась? $1.',
'nologinlink'               => 'Тейть совамотарка',
'createaccount'             => 'Теемс совицянь од лопа',
'gotaccount'                => 'Совамотаркат ули? $1.',
'gotaccountlink'            => 'Совамс',
'createaccountmail'         => 'е-сёрмасо',
'badretype'                 => 'Сёрмадыть салавань валот кавксть, сынь аволь вейкеть.',
'youremail'                 => 'Е-сёрма:',
'username'                  => 'Совицянь леметь:',
'uid'                       => 'Совицянь ID:',
'yourrealname'              => 'Алкуксонь леметь:',
'yourlanguage'              => 'Кель:',
'yournick'                  => 'Путонь леметь:',
'email'                     => 'Е-сёрма',
'prefs-help-realname'       => 'Алкуксонь лем (аульэрявикс паксясь): кодак тынь невтсынк сонзе, сон карми невтевеме кие теизеть лопанть витевксенть.',
'loginerror'                => 'Совамсто ильведькс',
'prefs-help-email-required' => 'Е-сёрмань адресэть эряви.',
'loginsuccesstitle'         => 'Салава валось уцяскав',
'loginsuccess'              => "'''Тон совить {{SITENAME}}-с кода \"\$1\".'''",
'nosuchuser'                => 'Совиця истямо $1 лем марто арась.
Ванынк видестэ сёрмадоманть али теинк одс совавтоманть од совицянть.',
'nosuchusershort'           => '"<nowiki>$1</nowiki>" лемсэ совиця арась. Варштака, кизды, аволь истя сёрмадозь.',
'nouserspecified'           => 'Совицянь лем эряви.',
'wrongpassword'             => 'Аволь истя сёрмадык салавань валот. Варчыка одов.',
'wrongpasswordempty'        => 'Салавань валот кадовсь апак сёрмадо. Сёрмадыка одов.',
'passwordtooshort'          => 'Салавань валот а маштови эли кувалмозо а саты. Эйсэнзэ эряволь улемс $1 тешкст, аволь седе аламо. Салавань валонтень эряви явовомс совицянь валонть эйстэ.',
'mailmypassword'            => 'Е-сёрмань салавань вал',
'passwordremindertitle'     => '{{SITENAME}} туртов акуватень од салавань вал',
'passwordremindertext'      => 'Кие-буди (кода неяви тон) IP-тешкстенть $1 кевкстизеть,<br />
минек кедсте кучомс тыненк совицянь од салава вал {{grammar:genitive|{{SITENAME}}}} ($4).<br />
Салава валось совицяньте $2 ней: <code>$3</code>.<br />
Тыненк эряви ней невтемс прянть системасонь ды полавтомонзо салава валонть.<br />

Кодак тынь эзиде кучне кевкстима салава валонть кис, али тынь лецтинк эсинк салав валонть, тынь илядо вано те сёрмадовксоньте ды саеде лезе эсинк сыре салав валонть.',
'noemail'                   => '"$1" совицянть арась е-сёрмапаргозо.',
'passwordsent'              => 'Од салав валось ульнесь кучозь e-mail -те, конань ульнезь невтезь $1 -нь совицяньте.<br />
Инескеть, невтинк прянк одс кода сы салав валось.',
'eauthentsent'              => 'Шкас салав валось ульнесь кучозь e-mail -те почта тешкстеньте од совицянть $1.<br /> Сёрмасонть максозь теевксне, конатань эряви теемс кемекстамоньте e-mail-нть конань кирдицякс улят тон.',
'mailerror'                 => 'Е-сёрма кучомсто ильведькс: $1',
'emailconfirmlink'          => 'Кемекстык е-сёрмапаргот',
'loginlanguagelabel'        => 'Кель: $1',

# Password reset dialog
'resetpass'         => 'Полавтомс совамотаркань салавань валот',
'resetpass_header'  => 'Аравтомс од салавань валот',
'resetpass_missing' => 'Формань дата арась.',

# Edit page toolbar
'bold_sample'     => 'Эчке текст',
'bold_tip'        => 'Эчке текст',
'italic_sample'   => 'Комавтонь текст',
'italic_tip'      => 'Комавтонь текст',
'link_sample'     => 'Сюлмавомапень конякс',
'link_tip'        => 'Потмоёндонь сюлмавомапе',
'extlink_sample'  => 'http://www.example.com налткенть лемезе',
'extlink_tip'     => 'Ушо ёнксонь сюлмавкс / налтке (мельсэ кирдить http:// путовксонть)',
'headline_sample' => 'Конякссонть текстэсь',
'headline_tip'    => 'Омбоце эскельксэнь конякс',
'math_sample'     => 'Совавтомс тезэнь хвормула',
'math_tip'        => 'Математикань хвормула (LaTeX)',
'nowiki_sample'   => 'Совавтомс хворматтомо текст тезэнь',
'nowiki_tip'      => 'Нулгодемс поладома-витнеманьте wiki',
'image_sample'    => 'Саемга.jpg',
'image_tip'       => 'Путонь медия файла',
'media_sample'    => 'Саемга.ogg',
'media_tip'       => 'Медия файлантень сюлмавома пе (налтке)',
'sig_tip'         => 'Тынк кедень путовксонк шканть марто',
'hr_tip'          => 'Менельгирьксень кикс (тевс нолдыть ванстозь)',

# Edit pages
'summary'                => 'Вейсэндязь',
'subject'                => 'Сёрмадовксонть лемезе',
'minoredit'              => 'Те апокшкэ витнема-петнема',
'watchthis'              => 'Ваномс те лопанть мельга',
'savearticle'            => 'Ванстомс лопанть',
'preview'                => 'Васнянь невтевкс',
'showpreview'            => 'Максомс васнянь невтевкс',
'showlivepreview'        => 'Эряй васнянь невтевкс',
'showdiff'               => 'Невтемс мезе полавтовсь',
'anoneditwarning'        => "'''Икелев мерема:''' Тынь апак сова. Тынк IP адрестенк карми совавтозь те витнема-петнема историянь лопасонть.",
'summary-preview'        => 'Цётомань седеикелев вановкс',
'blockedtext'            => "<big>'''Тынк уське коцтонь совамось али IP-тешкстенк сёлгазь-пекстазь.'''</big><br />

Сёлгизеть тонь $1 прявт кирдицясь. Невтезь истямо тувталось: ''«$2»''.<br />

* Сёлгоманть ушодавксось: $8
* Сёлгоманть прядомась: $6
* Ульнесь сёлгозь: $7

Тынк ули видечинк сёрмадомс сёрма совицяньте $1 али лиятьнене [[{{MediaWiki:Grouppage-sysop}}|прявт кирдицятнене]], ды кортамс сёлгоманть коряс.<br />
Мель яводо, тынь асёрмадовдтаводо сёрма прявт кирдицяньте, кодак тынь апак сова те уськеньте ды эзинк кемекста эсинк электронной тешкстенк [[{{ns:special}}:Preferences|эсить аравтоматьнесэ]], истяжо сестэ, кода тыненк ульнесь а мерезь ульнесь кучомс сёрмат сёлгоманть кувалт.<br />

Тынк IP-тешкстенк  — $3, сёлгоманть ID-сь — #$5. Инескеть, невтеде нетьнень тынк кевкстематнесе.",
'blockednoreason'        => 'тувтал апак максо',
'whitelistedittitle'     => 'Витнемань-петнемань кисэ эряви совамо лем',
'whitelistedittext'      => 'Лопань витнемс - петнемс эряви $1.',
'whitelistreadtitle'     => 'Ловномань кисэ эряви совамо лем',
'nosuchsectiontitle'     => 'Истямо явкс арась',
'loginreqtitle'          => 'Совамс эряви',
'loginreqlink'           => 'совамс',
'accmailtitle'           => 'Салавань вал кучозь.',
'newarticle'             => '(Од)',
'newarticletext'         => "Тынь молиде налткенть мельга сёрмадовксось конань эзь ульне теезь. 
Ули меленк теемс сёрмадовкс сёрмадодо валт ало паргосонть (вандодо [[{{MediaWiki:Helppage}}|help page]] тесэ лездамо информация). 
Кодак тынь тесэ ильветькс коряс, лепштядо '''back''' браузерсэ.",
'noarticletext'          => "Неень шкасто те лопасонть сёрмадовксось арась. Тынь мусынк [[{{ns:special}}:Search/{{PAGENAME}}|лецтнеманть те лемензе]] лия сёрмадовкснесэ али '''[{{fullurl:{{FULLPAGENAME}}|action=edit}} теемс лопа истямо леме марто]'''.",
'previewnote'            => '<strong>Это - ансяк икелев ваномась; полавтоматне эзть ульне ванстозь!</strong>',
'editing'                => 'Витнят-петнят $1',
'editingsection'         => 'Витнемс-петнемс $1 (секциянть)',
'yourtext'               => 'Мезе сёрмадыть',
'storedversion'          => 'Ванстозь версия',
'yourdiff'               => 'Мейсэ явовить',
'copyrightwarning'       => 'Инескеть тешкстынк, тынк внси путовксне {{SITENAME}}-се, кода арсетян нолдазь $2 ало (вант $1 педе пес). Кодак Тынк арась меленк тынк сермадовксось улевель витнезь-петнезь педте пес илядо сестэ путто сонзе тей.<br />
Тынь истяжо макстад вал сень коряс - тень Тынь сёрмадынк тыньдынсь, али саинк сонзэ вейсэнь ёнксто али олячинь порталсто. 
<strong>ИЛЯДО МАКСО ВАНСТОЗЬ ЛОМАНЕНЬ ВИДЕЧИСЭ ВАЖОДИМАНТЬ АПАК МЕЛЬТЕМЕ!</strong>',
'longpagewarning'        => '<strong>ИКЕЛЕ КАРДОМА: Те лопанть сталмозо $1 килобайтт; кона-конат интерчаматнесэ-браузертнесэ стакасто витнемсь-петнемс сёрмадовкс 32-во кб сталмосо али седе стака.
Инескеть, паро улевель лопанть явовтомс вишка пельксес.</strong>',
'templatesused'          => 'Те лопасонть тевс нолдазь лопапарцунт:',
'templatesusedpreview'   => 'Шаблонтне, конататьнень тевс нолдыть те икелеввановкссонть:',
'template-protected'     => '(ванстозь)',
'template-semiprotected' => '(пельс ванстазь)',
'nocreatetext'           => 'Те {{SITENAME}} лопасонть пирязь од лопань теемась. Тонь ули мелеть велявтомс удалов ды  питнемензе-витнемензе улиця лопанть, али [[Special:Userlogin|совамс али теемс од совама]].',
'recreate-deleted-warn'  => "'''Икелев кардома: Тынь откстомтавтад лопанть, кона ульнесь нардазь.'''
 
Васня арседе, эрява-арась полалемс ды витнем-петнемс те лопанть.
Вант те лопанть нардома лумонть ало:",

# History pages
'viewpagelogs'        => 'Сёрмадомонзо салававалонть те лопасонть',
'currentrev'          => 'Тевате лиякстомтома',
'revisionasof'        => '$1-це версиясь',
'revision-info'       => '$1 -нь лиякстомтома, конань теизе $2',
'previousrevision'    => '←Седе икелень лиякстомтома',
'nextrevision'        => 'Седе од вановкс→',
'currentrevisionlink' => 'Тевате лиякстомтома',
'cur'                 => 'неень',
'next'                => 'сыця',
'last'                => 'меельсе',
'orig'                => 'одксонь',
'page_first'          => 'васенце',
'page_last'           => 'меельсе',
'histlegend'          => "Версиняь кочкамось: тешксты невтезь верисятнень,  али лепштик Enter плаштиненть.<br />
Чарькодевтемат: (молиц.) = редямось молиця версиястонть; (и. молиц.) = редямось икеле молиця версиястонть; '''а''' = аульседе ламо лиякстома.",
'deletedrev'          => '[нардазь]',
'histfirst'           => 'Васенце',
'histlast'            => 'Меельсе',
'historysize'         => '({{PLURAL:$1|1 байт|$1 байтт}})',
'historyempty'        => '(чаво)',

# Revision feed
'history-feed-item-nocomment' => '$1 $2-зэ', # user at time

# Revision deletion
'rev-deleted-comment'  => '(арсемась-мелесь нардазь)',
'rev-deleted-user'     => '(совицянь лемесь нардазь)',
'rev-deleted-event'    => '(сёрмадсткэсь нандазь)',
'rev-delundel'         => 'невтемс/кекшемс',
'revdelete-hide-image' => 'Кекшемс мезе файлатнесэ',
'revdelete-log'        => 'Логто ёвтнема:',

# History merging
'mergehistory-from'           => 'Лисьмапря лопа:',
'mergehistory-no-source'      => 'Лисьмапрянь $1 лопась арась.',
'mergehistory-no-destination' => 'Норовазь $1 лопась арась.',

# Merge log
'mergelog'    => 'Вейтьсэндямс логонть',
'revertmerge' => 'Явомс логонть мекев, кода ульнесь вейтьсэндямодо икеле',

# Diffs
'history-title'           => 'Историясь ламо вановксонть "$1"',
'difference'              => '(Явовкс ванокснень юткова)',
'lineno'                  => 'Киксэсь $1:',
'compareselectedversions' => 'Ванномс саезь версиятьнень',
'editundo'                => 'Велявтомс мекев мезе витнинь-петнинь',
'diff-multi'              => '({{PLURAL:$1|$1 юткине версиясь апак невте|$1 юткине версиятне апак невте|$1 юткине версиятнеде апак невте.}})',

# Search results
'searchresults'         => 'Мезе муевсь',
'searchsubtitle'        => "Вешнить '''[[:$1]]'''",
'searchsubtitleinvalid' => "Вешнить '''$1'''",
'noexactmatch'          => "'''\"\$1\" конякс марто лопа арась.''' Мелеть ули, [[:\$1|теика те лопанть]].",
'noexactmatch-nocreate' => "'''\"\$1\" лемсэ лопа арась.'''",
'titlematches'          => 'Лопанть коняксонзо марто вейтьс прась',
'notitlematches'        => 'Лопанть коняксонзо марто вейтьс прамот арасть',
'textmatches'           => 'Лопанть сёрмадсткэнзэ марто вейтьс прамот',
'notextmatches'         => 'Лопанть сёрмадсткэнзэ марто вейтьс прамот арасть',
'prevn'                 => 'седе икелень $1',
'nextn'                 => 'сы $1',
'viewprevnext'          => 'Ванномс ($1) ($2) ($3)',
'powersearch'           => 'Вешнемс',

# Preferences page
'preferences'              => 'Лия ютксто явома',
'mypreferences'            => 'Монь лия ютксто явома',
'prefs-edits'              => 'Зяроксть витнезь-петнезь:',
'prefsnologin'             => 'Эзить сова',
'qbsettings-none'          => 'Арась мезе невтемс',
'qbsettings-fixedleft'     => 'Керш ёндо кирдезь',
'qbsettings-fixedright'    => 'Вить ёндо кирдезь',
'qbsettings-floatingleft'  => 'Керш ёнга уи',
'qbsettings-floatingright' => 'Вить ёнга уи',
'math'                     => 'Математика',
'dateformat'               => 'Чынь формат',
'datedefault'              => 'Икелькс вешема арась',
'datetime'                 => 'Чи ды шка',
'math_failure'             => 'А ловнови',
'math_unknown_error'       => 'апак содань ильведькс',
'math_unknown_function'    => 'апак содань функция',
'prefs-personal'           => 'Совицядо',
'prefs-rc'                 => 'Чиень полавтнемат',
'prefs-watchlist'          => 'Ванома лемрисьме',
'prefs-misc'               => 'Минеть-сюнот',
'saveprefs'                => 'Ванстомс',
'resetprefs'               => 'Аравтомс одов',
'oldpassword'              => 'Ташто салавань валот:',
'newpassword'              => 'Од салавань валот:',
'retypenew'                => 'Сёрмадык омбоцеде салавань валот:',
'textboxsize'              => 'Витнема-петнема',
'columns'                  => 'Палманть:',
'contextlines'             => 'Зяро рисьметь эрьва муевкссэ:',
'timezonelegend'           => 'Часовойть каркст',
'localtime'                => 'Тескэнь шкась',
'servertime'               => 'Серверэнь шка',
'files'                    => 'Файлат',

# User rights
'userrights-lookup-user'    => 'Сови куротнень ветямось',
'userrights-user-editname'  => 'Сёрмадт совицянь лем:',
'editusergroup'             => 'Витнемс-петнемс сови куротнень',
'saveusergroups'            => 'Ванстомс сови куротнень',
'userrights-reason'         => 'Полавтомань тувтал:',
'userrights-available-none' => 'Тонеть а мерить лиякстомтомс тень, кие кодамо сови куросо ашти.',

# Groups
'group'            => 'Группа:',
'group-bot'        => 'Ботт',
'group-sysop'      => 'Администраторт',
'group-bureaucrat' => 'Бюрократт',
'group-all'        => '(весе)',

'group-bot-member'        => 'Бот',
'group-sysop-member'      => 'Администратор',
'group-bureaucrat-member' => 'Бюрократ',

'grouppage-bot'        => '{{ns:project}}:Ботт',
'grouppage-sysop'      => '{{ns:project}}:Администраторт',
'grouppage-bureaucrat' => '{{ns:project}}:Бюрократт',

# User rights log
'rightslog' => 'Уськесовицянть видечинть кемекстома',

# Recent changes
'nchanges'                       => '$1 {{PLURAL:$1|полавтнема|полавтнемат}}',
'recentchanges'                  => 'Чыяконь полавтнемат-лиякстомтомат',
'recentchanges-feed-description' => 'Мельга ваннынк кода ульнесть витьнемат-петнемат wiki-сэ те максовксонть.',
'rcnote'                         => "{{PLURAL:$1|Меельце '''$1''' лиякстома|Меельцеть '''$1''' лиякстомат|Меельце '''$1''' лиякстоматьне}}  '''$2''' {{plural:$2|чи|чинть|читьнень}}, те $3 шканть коряс.",
'rcnotefrom'                     => 'Ало невтезь лиякстоматьне  <strong>$2</strong>-ста марто (<strong>$1</strong>-с).',
'rclistfrom'                     => 'Невтемс од витьнематьнень $1-нтсэ.',
'rcshowhideminor'                => '$1 апокшкэ витнемат-петнемат',
'rcshowhidebots'                 => '$1 ботт',
'rcshowhideliu'                  => '$1 совазь уськекирдицятьне',
'rcshowhideanons'                => '$1 лемтеме совицят',
'rcshowhidepatr'                 => '$1 кона патрульсэ витьни-петни',
'rcshowhidemine'                 => '$1 мезе мон витнинь-петнинь',
'rclinks'                        => 'Невтемс меельсе $1 полавтнемат меельсе $2 чинь перть<br />$3',
'diff'                           => 'кадовикс',
'hist'                           => 'ист',
'hide'                           => 'Кекшемс',
'show'                           => 'Невтемс',
'minoreditletter'                => 'а',
'newpageletter'                  => 'О',
'boteditletter'                  => 'б',

# Recent changes linked
'recentchangeslinked'          => 'Сюлмавозь лиякстоматьне',
'recentchangeslinked-title'    => 'Полавтнемат-лиякстомтомат конат кандовить теватезэнь $1',
'recentchangeslinked-noresult' => 'Кодаткак полавтомат сюлмавозь лопатьнесэ те шкастонть.',
'recentchangeslinked-summary'  => "Те башка лопасонть максозь потмокс меельцень витнематьнень-петнематнень, сулмавозь лопатнесэ. Лопатне ванома потмоксто '''эчкестэ тештезь'''",

# Upload
'upload'           => 'Ёкстамонзо файланть',
'uploadbtn'        => 'Тонгомс файланть',
'uploadnologin'    => 'Эзить сова',
'uploadlogpage'    => 'Файлань тонгома журналось',
'filename'         => 'Файлонь лем',
'successfulupload' => 'Совавтовсь кода эряви',
'uploadwarning'    => 'Совавтомадо кардамонь пачтямо',
'savefile'         => 'Ванстомс файланть',
'uploadedimage'    => 'тонгозь "[[$1]]"',
'uploaddisabled'   => 'Совавтомась лоткавтозь',
'uploadvirus'      => 'Те файласонть вирус програм! Информация: $1',
'sourcefilename'   => 'Лисьмапрянть файлань лемезэ',
'destfilename'     => 'Норовазенть файлань лемезэ',
'watchthisupload'  => 'Ваномс те лопанть мельга',

'upload-file-error' => 'Потмонь ильведькс',

# Image list
'imagelist'                 => 'Файлат-мезть',
'imgfile'                   => 'файл',
'filehist'                  => 'Файланть эрямопингезэ',
'filehist-help'             => 'Лепштинк чиннть/шканть ланкс, сестэ вансынк коли файлось ульнесь теезь.',
'filehist-current'          => 'неень шкань',
'filehist-datetime'         => 'Чи/Шка',
'filehist-user'             => 'Совиця',
'filehist-dimensions'       => 'Онкставкс',
'filehist-filesize'         => 'Файланть покшолмазо',
'filehist-comment'          => 'Мельполадкс',
'imagelinks'                => 'Сюлмавомапеть',
'linkstoimage'              => 'Те файлантень сюлмазь вана истят сюлмавомапеть:',
'nolinkstoimage'            => 'Арасть вейкеяк лопать, конат сюлмавовить те файланть марто.',
'sharedupload'              => 'Те файлась вачказезь вейксеньте знярыянь проектень ванстома таркас.',
'noimage'                   => 'Кодамояк файла истямо лем марто арась, тынь $1 тейдяд.',
'noimage-linktext'          => 'тонгинк тень',
'uploadnewversion-linktext' => 'Тонгодо од версия те файланть',
'imagelist_date'            => 'Чи',
'imagelist_name'            => 'Лем',

# File reversion
'filerevert-comment' => 'Арсемат-мельть:',

# File deletion
'filedelete'             => 'Нардамс $1',
'filedelete-legend'      => 'Нардамс файланть',
'filedelete-comment'     => 'Мейс нардамс:',
'filedelete-submit'      => 'Нардамс',
'filedelete-success'     => "'''$1'''-сь нардазь.",
'filedelete-otherreason' => 'Лия тувтал:',

# MIME search
'mimesearch' => 'MIME вешнема',
'download'   => 'таргамс',

# List redirects
'listredirects' => 'Лияв адрессев кучома потмо',

# Unused templates
'unusedtemplates'    => 'Тевс апак нолда лопапарцунт',
'unusedtemplateswlh' => 'лия сюлмавома пенеть',

# Random page
'randompage'         => 'Кодамо понгсь лопа',
'randompage-nopages' => 'Те лем таркасонть лопат арасть.',

# Random redirect
'randomredirect'         => 'Апак фатя ёнксось',
'randomredirect-nopages' => 'Те лем таркасонть лияв ютавтомат арасть.',

# Statistics
'statistics' => 'Статистикат',
'sitestats'  => '{{SITENAME}} статистика',
'userstats'  => 'Совицянь статистика',

'disambiguations' => 'Лопат, конат сёрмадстовтовить ламосмустев терминтт',

'doubleredirects' => 'Кавксть ютавтозь',

'brokenredirects' => 'Сезезь ёнксось',

'withoutinterwiki' => 'Лопат келеньютковань невтевкснень теме',

'fewestrevisions' => 'Лопатьне седе аламонь вановкснэнь марто',

# Miscellaneous special pages
'nbytes'                  => '$1 {{PLURAL:$1|байт|байтт}}',
'ncategories'             => '$1 {{PLURAL:$1|категория|категорият}}',
'nlinks'                  => '$1 {{PLURAL:$1|невтевкс|невтевкст|невтевкснедэ}}',
'nmembers'                => '$1 {{PLURAL:$1|совиця|совицятне}}',
'nrevisions'              => '$1 {{PLURAL:$1|лиякстомтома|лиякстомтомат}}',
'lonelypages'             => 'Лопаурозкэть',
'uncategorizedpages'      => 'Категориявтомо лопат',
'uncategorizedcategories' => 'Категориявтомо категорият',
'uncategorizedimages'     => 'Категориявтомо файлат',
'uncategorizedtemplates'  => 'Категориявтомо лопапарцунт',
'unusedcategories'        => 'Тевс апак нолда категорият',
'unusedimages'            => 'Тевс апак нолда файлат',
'popularpages'            => 'Раське ютксо вечкевикс лопат',
'wantedcategories'        => 'Вешезь категориятьне',
'wantedpages'             => 'Вешевикс лопатьне',
'mostlinked'              => 'Сехте сюлмавозь лопатьнень марто',
'mostlinkedcategories'    => 'Сехте сюлмавозь категориятнень марто',
'mostlinkedtemplates'     => 'Сехте сюлмавозь шаблонтнень марто',
'mostcategories'          => 'Весемеде ламо категория марто лопат',
'mostimages'              => 'Сехте сюлмавозь фотокувтнень марто',
'mostrevisions'           => 'Лопатьне сехте ламо вановксов марто',
'allpages'                => 'Весе лопат',
'prefixindex'             => 'Невтевкс валтнень ушоткснень коряс',
'shortpages'              => 'Нурькине лопат',
'longpages'               => 'Кувака лопат',
'deadendpages'            => 'Апаклисема марто лопат',
'protectedpages'          => 'Ванстазь лопатьне',
'listusers'               => 'Совицят-кить',
'specialpages'            => 'Башка тевень лопат',
'newpages'                => 'Од лопат',
'newpages-username'       => 'Совицянь лем:',
'ancientpages'            => 'Весемеде умонь лопат',
'move'                    => 'Сыргамо',
'movethispage'            => 'Ютавтомс те лопанть лияв',

# Book sources
'booksources' => 'Кинигань лисьмапрят',

'alphaindexline' => '$1-сь  $2-те',
'version'        => 'Версия',

# Special:Log
'specialloguserlabel'  => 'Совиця:',
'speciallogtitlelabel' => 'Конякс:',
'log'                  => 'Салав валось (регистрациясь)',
'all-logs-page'        => 'Веси совамотне-кемекстамотьне',

# Special:Allpages
'nextpage'       => 'Сы лопа ($1)',
'prevpage'       => 'Седе икелень лопа ($1)',
'allpagesfrom'   => 'Невтема лопатьне, ушодовицятне:',
'allarticles'    => 'Весе сёрмадовкст',
'allinnamespace' => 'Весе лопат ($1 сёрмадовксонть лемезе)',
'allpagesprev'   => 'Икеле',
'allpagesnext'   => 'Сыця',
'allpagessubmit' => 'Молемс',
'allpagesprefix' => 'Невтевкс лопась полаткс марто:',

# E-mail user
'emailuser'       => 'Те совицянтень кучомс е-сёрма',
'defemailsubject' => '{{SITENAME}} е-сёрма',

# Watchlist
'watchlist'            => 'Мезе мельга мон ванстнян',
'mywatchlist'          => 'Мезе мельга мон ванстнян',
'watchlistfor'         => "('''$1'''-те)",
'addedwatch'           => 'Топавтозь ванома потмоксоньте',
'addedwatchtext'       => 'Лопась «[[:$1]]» ульнесь топавтозь тынк [[{{ns:special}}:Watchlist|ванома потмо]]. Седе тов витнематьне те лопанть ды сулмавозь сонзе марто кортамтома лопанть кармить тешкставтовомо те потмосонть, истяжо кармить кикстазь те лопасонть[[{{ns:special}}:Recentchanges|потмо од витнематьнень]] марто, истя седе шождасто сынь неявить.<br />
Кодак мейле тынк карми меленк нардамонзо лопанть ванома помокстонть, лепштинк плаштиненть «а ваномс мельга» вить ёнонь верькссенть лопанть.',
'removedwatch'         => 'Нардазь ванома потмокстонть',
'removedwatchtext'     => 'Лопась «[[:$1]]» ульнесь нардазь тынк ванома потмокстонть.',
'watch'                => 'Ванстнемс',
'watchthispage'        => 'Ванстнемс те лопа мельга',
'unwatch'              => 'А ванстнемс тень мельга',
'watchlist-details'    => '$1 {{plural:$1|лопа|лопат|лопатнеде}}, апак лова кортнема лопатнень.',
'wlshowlast'           => 'Невтемс мельсе $1 цяст $2 чить $3',
'watchlist-hide-bots'  => 'Кекшэмс мезе ботось витнесь-петнесь',
'watchlist-hide-own'   => 'Кекшэмс мезе мон витнинь-петнинь',
'watchlist-hide-minor' => 'Кекшэмс апокшкэ витнемат-петнемат',

# Displayed when you click the "watch" button and it's in the process of watching
'watching'   => 'Ванома...',
'unwatching' => 'Аванома...',

'enotif_anon_editor' => 'лемтеме совиця $1',

# Delete/protect/revert
'deletepage'                  => 'Панемс лопанть',
'confirm'                     => 'Кемекстамс',
'historywarning'              => 'Икелев мерема: Лопанть, конань тынь пурнатад нардамонзо улить лиякстомань историянзо:',
'confirmdeletetext'           => 'Тынь кевкстинк пешксе нардоманть  лопанть (али невтевкс-артовксонть)ды веси сонзе лиякстомань историянзо.<br />
Инескеть,  кемекстынк, эсинк меленк тень коряс, ды содасынк кадовкснень тень мельга,  ды тейдяд тень видечинть (правилатьнень) коряс, конат сёрмадозь [[{{MediaWiki:Policy-url}}]].',
'actioncomplete'              => 'Тевень теемась топавтовсь',
'deletedtext'                 => '"<nowiki>$1</nowiki>"-сь ульнесь нардазь.
Вант $2 тосо веси уаль умоконь нардавксне.',
'deletedarticle'              => 'нардазь "[[$1]]"',
'dellogpage'                  => 'Нардомань совама-кемекстома',
'deletecomment'               => 'Тувтал печкеме:',
'deleteotherreason'           => 'Лия/топавтозь тувтал:',
'deletereasonotherlist'       => 'Лия тувтал',
'rollbacklink'                => 'кевердемс',
'protectlogpage'              => 'Ванстомань совама-кемекстома',
'confirmprotect'              => 'Кемекстынк аравтоманть лопанть ванстоманзо',
'protectcomment'              => 'Мельполадкс:',
'protectexpiry'               => 'Прядови:',
'protect_expiry_invalid'      => 'Прядома шкась ашти ютань шкасо.',
'protect_expiry_old'          => 'Прядома  шкась амаштовикс.',
'protect-unchain'             => 'Панжомс сыргамонь нолдамонть',
'protect-text'                => 'Тесэ тынь вансынк ды лиякстомсынк ванстоманть покшолманзо лопаньте <strong>[[:$1]]</strong>.',
'protect-locked-access'       => 'Тынк кирдицянк совамонть асатыть видечись лиякстоманьте ванстома сэреньте лопанть. Нень шкань путовксне те лопаньте <strong>[[:$1]]</strong>:',
'protect-cascadeon'           => 'Те лопась ванстозь,  сон путозь {{PLURAL:$1|невтезезь ало лопаньте, конаньте|невтезезь ало лопатьнене конатьнене}}-те путозь каскадонь ванстомась. Тынь лиякставсынк те ванстома сэренть, ансяк те кодаяк а полавсы каскадонь ванстоманть.',
'protect-default'             => '(апандовкс)',
'protect-fallback'            => 'Вешеви ве мельс прамось «$1»-нть',
'protect-level-autoconfirmed' => 'Пекстадо апакускекотцто совицятьнень',
'protect-level-sysop'         => 'Ансяк администраторт',
'protect-summary-cascade'     => 'каскадонь лацо',
'protect-expiring'            => 'прядови $1 (UTC)',
'protect-cascade'             => 'Ванстомс лопатьнень, конат совавтозь те лопаньте(каскадонь ванстома)',
'protect-cantedit'            => 'Тынь алиякставсынк ванстомань уровнянть те лопанть, тынк арасть видечинк сонзэ лиякстоманьте.',
'restriction-type'            => 'Нолдамо:',
'restriction-level'           => 'Нолдавксонь покшизэ:',
'pagesize'                    => '(байтт)',

# Undelete
'undeletebtn'            => 'Велявтомс мекев сенень, мезе ульнесь витнемадо-петнемадо икеле',
'undeletecomment'        => 'Арсемат - мельть:',
'undelete-search-prefix' => 'Невтемс лопат тестэ саезь:',
'undelete-search-submit' => 'Вешнемс',

# Namespace form on various pages
'namespace'      => 'Сёрмадовксонть лемезе:',
'invert'         => 'Велявтомс якстерьгавтозенть-невтевезенть',
'blanknamespace' => '(Прявкс)',

# Contributions
'contributions' => 'Совицянть-кирдицянть путовксозо',
'mycontris'     => 'Монь путовкст',
'contribsub2'   => '$1 ($2) туртов',
'uctop'         => '(меельцесь)',
'month'         => 'Ковстонть (ды седе икеле):',
'year'          => 'Иестэнть (ды седе икеле):',

'sp-contributions-newbies-sub' => 'Од акаунтс',
'sp-contributions-blocklog'    => 'Пекстамонь журналось',
'sp-contributions-username'    => 'IP адрес эли совицянь лем:',
'sp-contributions-submit'      => 'Вешнемс',

# What links here
'whatlinkshere'       => 'Мезе тезэнь сюлмави',
'whatlinkshere-title' => 'Лопат конат сюлмазь $1 марто',
'whatlinkshere-page'  => 'Лопа:',
'linklistsub'         => '(Налткень потмокс)',
'linkshere'           => "Сыця лопатьне сюлмававить '''[[:$1]]''' марто:",
'nolinkshere'         => "Кодаткак лопат асульмавить '''[[:$1]]''' марто.",
'isredirect'          => 'Лиякс витнинк-петнинк лопанть',
'istemplate'          => 'совавтомс',
'whatlinkshere-prev'  => '{{PLURAL:$1|икеле|седе икелень $1}}',
'whatlinkshere-next'  => '{{PLURAL:$1|сыця|сы $1}}',
'whatlinkshere-links' => '← сюлмавомапеть',

# Block/unblock
'blockip'            => 'Пекстамондо совицянть',
'ipaddress'          => 'IP адрес:',
'ipadressorusername' => 'IP адрес эли совицянь лем:',
'ipbreason'          => 'Тувтал:',
'ipbreasonotherlist' => 'Лия тувтал',
'ipboptions'         => '2 hours:2 част,1 day:1 чи,3 days:3 чить,1 week:1 тарго,2 weeks:2 таргот,1 month:1 ков,3 months:3 ковт,6 months:6 ковт,1 year:1 ие,infinite:певтеме', # display1:time1,display2:time2,...
'ipblocklist'        => 'Лопась пексать IP адресстнэнь ды совицятьнень',
'blocklink'          => 'блокось',
'unblocklink'        => 'панжомс',
'contribslink'       => 'лездыцят кить',
'blocklogpage'       => 'Пекстамонь журналось',
'blocklogentry'      => 'пектстамонзо [[$1]]  ютазь шканть марто $2 $3',

# Move page
'movepage'         => 'Лопанть лемень полавтома',
'movepagetext'     => "Тевс нолдазь ало лувонть,  тынь од лемдясынк лопанть, ве шкасто путсынк од таркас сонзе лиякстома журналонть.<br />
Сыре лемезе карми тейсырьксезь од леменьте.<br />
Невтевксне сыре леменьте акармить лиякстовтозь (инескеть, ванынк улеманть [[{{ns:special}}:DoubleRedirects|кавтонь]] ды [[{{ns:special}}:BrokenRedirects|сезезь]] сыркстамотьнень).<br />
Тынь кемекставстадо невтевкстне ды седе тов невтить тов, ков арсесть.<br />

Мель яводо, лопась  '''а карми''' одс лемдязь, кодак лопась од лементь марто нейке ули (тевтнеде башка, кодак сон тейсырькстамо али чаво ды сонзе арасть витнема историянзо). Те невти тынь од лемдясынк одов се леменьте, кона сонзе нейке ульнесь; кодак тынь одс лемдинк манявкс коряс, ансяк тынь а нардасынк-ёзасынк улема лопанть.<br />

'''ИЕЛЕ МЕРЕМА!'''<br />
Одс лемдямось тусы покш ды  а кирдевикс полавтоматьнене ''весименень содавиксэв'' лопатненэ. Инескеть, васня, коли тыть поладсынк, кемевтинк икеле молиматьнень.",
'movepagetalktext' => "Поладозь кортавтома лопась, кодак истямось ули карми автоматокс одов лемдязь, '''башка тевтнеде, коли:'''<br />

*Ауль чаво кортавтома лопась нейке ули истямо лем марто
*Тынь эзиде путо тешкст паксясонь ало.<br />

Не тевтнесэ, тынь тыньдынсь лияв кучсынк али сюлмасынк лопатьнень кедьсэ , кодат те тыненк эряви.",
'movearticle'      => 'Одов лемдемс лопанть:',
'newtitle'         => 'Од леменьтэ:',
'move-watch'       => 'Ваномс лопанть',
'movepagebtn'      => 'Одов лемдемс лопанть',
'pagemovedsub'     => 'Лопась одов лемдязь',
'movepage-moved'   => "<big>'''«$1»-сь одов лемдязь «$2»-с'''</big>", # The two titles are passed in plain text as $3 and $4 to allow additional goodies in the message.
'articleexists'    => 'Лопась истямо лем марто ули али невтезь тынк эйсэ лемесь анолдавиксев.<br />Инескеть, кочкадо лия лем.',
'talkexists'       => "'''Лопась ульнес одов лемдязь, ансяк кортамонь лопась кодаяк одов алемдяви, вана мекс,  истямо лем марто лопась ули. Инескеть, вейс пурнынк сынст кедьсэ.'''",
'movedto'          => 'печтевтезь',
'movetalk'         => 'Сыргамот, конат улить кортамо-лопасонть',
'talkpagemoved'    => 'Истяможо кортнема лопась ульнесь истяжо одов лемдязь.',
'talkpagenotmoved' => 'Истяможо кортнема лопась <strong>эзь</strong> ульне истяжо одов лемдязь.',
'1movedto2'        => '[[$1]] ютавтозь тей [[$2]]',
'movelogpage'      => 'Одс лемдявтомань журналось',
'movereason'       => 'Тувтал:',
'revertmove'       => 'велявтодо',

# Export
'export' => 'Экспортировамс лопат',

# Namespace 8 related
'allmessages' => 'Систэмань вишка сёрмадовкс',

# Thumbnails
'thumbnail-more'  => 'Покшолгавтомс',
'thumbnail_error' => 'Миниатюрань тееманть ильветькс: $1',

# Special:Import
'import-revision-count' => '$1 {{PLURAL:$1|лиякстомтома|лиякстомтомат}}',

# Import log
'importlogpage'                 => 'Импортонть журналось',
'import-logentry-upload-detail' => '$1 {{PLURAL:$1|лиякстомтома|лиякстомтомат}}',

# Tooltip help for the actions
'tooltip-pt-userpage'             => 'Совицянь лопам',
'tooltip-pt-mytalk'               => 'Кортнемалопам',
'tooltip-pt-preferences'          => 'Монь лия ютксто явома',
'tooltip-pt-watchlist'            => 'Лопань потмакс конататьненть Тынь вандад лиякстоманть коряс',
'tooltip-pt-mycontris'            => 'Мезесэ мон лездынь',
'tooltip-pt-login'                => 'Совавтовлить эсь прят тезэнь, арась мелеть, иля.',
'tooltip-pt-logout'               => 'Лисемс',
'tooltip-ca-talk'                 => 'Кортавтома пек паро лопадонть',
'tooltip-ca-edit'                 => 'Те лопаськак витневи-петневи. Ансяк, ванстомадо икеле яла васнянь невтевкс повнэнть лепштика.',
'tooltip-ca-addsection'           => 'Топавтодо мельполадкс кортавтоманьте.',
'tooltip-ca-viewsource'           => 'Те лопась ванстозь. Ули меленк ваномонзо сонзе лисмапрянть.',
'tooltip-ca-protect'              => 'Аравтомс те лопанть прянь ванстомас',
'tooltip-ca-delete'               => 'Нардамс те лопанть, илязо улеяк',
'tooltip-ca-move'                 => 'Ютавтык те лопанть лияв',
'tooltip-ca-watch'                => 'Топавтомс те лопанть тынк ваномалопаньте',
'tooltip-ca-unwatch'              => 'Панемензе (нардамонзо) те лопанть тынк ваномалопастонть',
'tooltip-search'                  => 'Вешнемс вана тестэ {{SITENAME}}',
'tooltip-n-mainpage'              => 'Совака прякслопантень',
'tooltip-n-portal'                => 'Проектэнть эйстэ,  мейсэ Тынь лездатад, косо муемс курмот-кармот',
'tooltip-n-currentevents'         => 'Муинк совавикс информациянть неень событиятнесэ',
'tooltip-n-recentchanges'         => 'Викисэ мезе чияк полавтовсь-лиякстомтовсь.',
'tooltip-n-randompage'            => 'Макста ловномс кодамо понгсь лопа',
'tooltip-n-help'                  => 'Превс путыть косо.',
'tooltip-n-sitesupport'           => 'Макста миненек нежедематарка',
'tooltip-t-whatlinkshere'         => 'Викинь весе лопатне, конат тезэнь сюлмазь',
'tooltip-t-contributions'         => 'Варштык путовкс потмонть те совицянть',
'tooltip-t-emailuser'             => 'Те совицянтень кучомс е-сёрма',
'tooltip-t-upload'                => 'Ёкстамс файлат',
'tooltip-t-specialpages'          => 'Башка тевень лопатне мельга-мельцек',
'tooltip-ca-nstab-user'           => 'Ваномс совицянь лопанть',
'tooltip-ca-nstab-project'        => 'Ваннынк проетной лопанть',
'tooltip-ca-nstab-image'          => 'Ванынк фотокувонть лопанть',
'tooltip-ca-nstab-template'       => 'Ванномс лопапарцунонть',
'tooltip-ca-nstab-help'           => 'Ванномс лездамонь лопанть',
'tooltip-ca-nstab-category'       => 'Варштынк категориянь лопатьнень',
'tooltip-minoredit'               => 'Тешкстынк тень, сон вишкинесте витнезь-петнезь',
'tooltip-save'                    => 'Ванстомс мезе лиякстомтыть',
'tooltip-preview'                 => 'Ванодо тынк лиякстоматнень, инескеть тевс нолдадо тень ванстоманть икеле!',
'tooltip-diff'                    => 'Невтемс мейсэ лиякстомтыть текстэнть.',
'tooltip-compareselectedversions' => 'Вант явовкст кавто саезь версиятнень те лопанть.',
'tooltip-watch'                   => 'Топавтомс те лопанть тынк ваномалопаньте',

# Spam protection
'subcategorycount'       => 'Те категриясонть $1 {{PLURAL:$1|категорияньалкс|категорияньалкст|категорияньалкстнеде}}.',
'categoryarticlecount'   => 'Те категориясонть $1 {{PLURAL:$1|сёрмадовкс|сёрмадовкст|сёрмадовкстнеде}}.',
'category-media-count'   => 'Те категориясонть $1 {{PLURAL:$1|файла|файланть|файлатнеде}}.',
'listingcontinuesabbrev' => 'поладовксось моли',

# Browsing diffs
'previousdiff' => '← Седе икелень diff',
'nextdiff'     => 'Сы кадовиксэсь →',

# Media information
'widthheightpage'      => '$1×$2, $3 лопат',
'file-info'            => '(файлонть-путовксонть сталмозо: $1, MIME типезе: $2)',
'file-info-size'       => '($1 × $2 пиксельть, файлонть-путовксонть сталмозо: $3, MIME типезе: $4)',
'file-nohires'         => '<small>Арась версия покш разрешения марто.</small>',
'svg-long-desc'        => '(SVG файла, $1 × $2 пиксельть, файланть покшолмазо: $3)',
'show-big-image'       => 'Пешксе теевксесь',
'show-big-image-thumb' => '<small>Покшолма икелев ваноманть: $1 × $2 пиксэлт</small>',

# Special:Newimages
'newimages'    => 'Од файлатьнень галлереясь',
'showhidebots' => '($1 ботт)',

# Bad image list
'bad_image_list' => 'Лувось-форматось эряви истямокс улевель:

Кармить лововомо ансяк потмонть элементне (киксне, конат ушодовить * тешкстсэ). Васенце невтевксесь эряви улевель невтевксекс а мерицянь артовксонь ёкстамсто.
Седе тов невтевкстне секе же киксенть кармить лововомо кода нардамот, лиякс меремс сёрмадовксне, ков артовксось ёкставиндеряй.',

# Metadata
'metadata'          => 'Meta-нь даннойтне',
'metadata-help'     => 'Те вайлась кирди потмосо топавтозь информация, кона топавтозь цифровой камерасто, али сулеймашинасто (скенерстэ) ды кона ульнесь теезь цифровой лувс. Сесте кода файлась ульнесь лиякстозь сонзе  невтевксензе эйсте, кой-кона пельксензе аневтить лиякстозь фотоартовксонть.',
'metadata-expand'   => 'Невтемс топавтозь даннойтнень',
'metadata-collapse' => 'Пекстынк келейкстазь детальтнень.',
'metadata-fields'   => 'Матадань паксятьне, конататьне ловозь те потмосонть, кармить невтезь артома лопасонть а сёпазь, лиятне кармить кекшезезь.
* make
* model
* datetimeoriginal
* exposuretime
* fnumber
* focallength', # Do not translate list items

# External editor support
'edit-externally'      => 'Витнемс-петнемс те файланть, тевс нолдазь ушо ёнксонь программанть',
'edit-externally-help' => 'Вант [http://meta.wikimedia.org/wiki/Help:External_editors аравтома инструкциятнень ] седе ламо информациянть кис.',

# 'all' in various places, this might be different for inflected languages
'recentchangesall' => 'весе',
'imagelistall'     => 'весе',
'watchlistall2'    => 'весе',
'namespacesall'    => 'весе',
'monthsall'        => 'весе',

# action=purge
'confirm_purge_button' => 'ОК',

# Multipage image navigation
'imgmultigo' => 'Адя!',

# Auto-summaries
'autosumm-new' => 'Од лопа: $1',

# Watchlist editing tools
'watchlisttools-view' => 'Лиякстоматьне лопатнесэ потмоксстонть',
'watchlisttools-edit' => 'Ваномс ды витнемс-петнемс мезе мельга ванстнят',
'watchlisttools-raw'  => 'Витнедэ начко ваномалопанть',

# Special:Filepath
'filepath-page' => 'Файл:',

);
