<?php
/** Old Norse (Norrǿna)
 *
 * @addtogroup Language
 *
 * @author SPQRobin
 */

$fallback = 'is';

$messages = array(
'help'             => 'Ásjá',
'search'           => 'Leita',
'searchbutton'     => 'Leita',
'talkpagelinktext' => 'Umræða',
'talk'             => 'Umræða',
'jumptosearch'     => 'leita',

'showtoc' => 'syna',
'hidetoc' => 'fela',

# Search results
'powersearch' => 'Leita',

);
