<?php
/** Abkhazian (Аҧсуа)
 *
 * @addtogroup Language
 *
 */

$fallback = 'ru';

