<?php
/** Inuktitut (ᐃᓄᒃᑎᑐᑦ/inuktitut)
 *
 * @addtogroup Language
 * @comment Macro language; kept for backward compatibility
 *
 */

$fallback = 'ike-cans';

