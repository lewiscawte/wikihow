<?php
/** 
  *
  * @addtogroup Language
  */

$rtl = true;
