<?php
/** Serbian Cyrillic ekavian (ијекавица)
 *
 * @addtogroup Language
 *
 */

# Inherit everything for now
$fallback = 'sr-ec';

