<?php
/** Megleno-Romanian (Greek script) (Βλαεστε)
 *
 * @addtogroup Language
 *
 */

$fallback = 'el';

