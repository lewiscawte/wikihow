<?php
/** Kazakh (Kazakhstan) (Қазақша (Қазақстан))
 *
 * @addtogroup Language
 *
 */

# Inherit everything for now
$fallback = 'kk-cyrl';

