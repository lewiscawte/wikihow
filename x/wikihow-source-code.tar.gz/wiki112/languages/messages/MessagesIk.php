<?php
/** Inupiaq (Iñupiak)
 *
 * @addtogroup Language
 *
 */

$messages = array(
# All link text and link target definitions of links into project namespace that get used by other message strings, with the exception of user group pages (see grouppage) and the disambiguation template definition (see disambiguations).
'helppage'        => 'Help:anniqsuiruq',
'mainpage'        => 'Makpibaaq Kanna',
'portal-url'      => 'Project:qargi',
'sitesupport-url' => 'Project:tunixabaa',

);
