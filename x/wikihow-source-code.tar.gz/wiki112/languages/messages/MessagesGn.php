<?php
/** Guaraní (avañe'ẽ)
  *
  * @addtogroup Language
  */

$fallback = 'es';

$namespaceNames = array(
	# NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Mba\'echĩchĩ',
	NS_MAIN             => '',
	NS_TALK             => 'Myangekõi',
	NS_USER             => 'Puruhára',
	NS_USER_TALK        => 'Puruhára_myangekõi',
	# NS_PROJECT set by $wgMetaNamespace
	NS_PROJECT_TALK     => '$1_myangekõi',
	NS_IMAGE            => 'Ta\'ãnga',
	NS_IMAGE_TALK       => 'Ta\'ãnga_myangekõi',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_myangekõi',
	NS_TEMPLATE         => 'Tembiecharã',
	NS_TEMPLATE_TALK    => 'Tembiecharã_myangekõi',
	NS_HELP             => 'Pytyvõ',
	NS_HELP_TALK        => 'Pytyvõ_myangekõi',
	NS_CATEGORY         => 'Ñemohenda',
	NS_CATEGORY_TALK    => 'Ñemohenda_myangekõi'
);
